# SingleMoleculeImageAnalyzer
Single molecule image analyzer

Input: 512x512 pixel uint8 CCD image

Written by S.H. Kim, (ifolium@gmail.com)
